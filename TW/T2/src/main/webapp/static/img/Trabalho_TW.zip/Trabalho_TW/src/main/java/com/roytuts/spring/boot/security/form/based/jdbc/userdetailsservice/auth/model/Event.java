package com.roytuts.spring.boot.security.form.based.jdbc.userdetailsservice.auth.model;

import java.util.Date;

public class Event {

    private Long id;
    private String name;
    private String description;
    private Date date;
    private double value;

    public Event() {
    }

    public Event(String name, String description, Date date, double value) {
        this.name = name;
        this.description = description;
        this.date = date;
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public double getValue() {
        return value;
    }

    public void setValue(double value) {
        this.value = value;
    }
}
