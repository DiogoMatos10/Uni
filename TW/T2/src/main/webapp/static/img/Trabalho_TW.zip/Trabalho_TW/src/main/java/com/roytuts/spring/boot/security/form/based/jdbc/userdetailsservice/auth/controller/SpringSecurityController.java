package com.roytuts.spring.boot.security.form.based.jdbc.userdetailsservice.auth.controller;

import com.roytuts.spring.boot.security.form.based.jdbc.userdetailsservice.auth.dao.Handler;
import com.roytuts.spring.boot.security.form.based.jdbc.userdetailsservice.auth.model.User;
import com.roytuts.spring.boot.security.form.based.jdbc.userdetailsservice.auth.model.Event;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.json.JSONArray;
import org.json.JSONObject;


import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.*;


@Controller
public class SpringSecurityController {

    @Autowired
    private Handler handler;

    @GetMapping("/")
    public String defaultPage(String type, Model model, HttpServletRequest request) throws Exception {
        if (request.getUserPrincipal() == null) {
            model.addAttribute("options", "<a href=\"/login\">Sign in</a> | <a href=\"/newuser\">Register</a>");

            if(type==null){
                type="live";
            }

            JSONArray events=handler.getEvents(type,null,null);
            StringBuilder builder = new StringBuilder();
            System.out.println(type);
            if (events.isEmpty()) {
                builder.append("<p>Não há eventos disponiveis</p>");
            } else {
                builder.append("<div class=\"events_list\">");
                builder.append("<table>"
                        + "<tr>"
                        + "<th>Nome do evento</th>"
                        + "<th>Descrição</th>"
                        + "<th>Data</th>"
                        + "<th>Preço</th>"
                        + "<th></th>"
                        + "</tr>");

                for (int i = 0; i < events.length(); i++) {
                    JSONObject event = events.getJSONObject(i);

                    String dateWithoutHour = event.getString("date").substring(0, event.getString("date").indexOf(" "));

                    builder.append("<tr>"
                                    + "<td>").append(event.getString("event")).append("</td>"
                                    + "<td>").append(event.getString("description")).append("</td>"
                                    + "<td>").append(dateWithoutHour).append("</td>"
                                    + "<td>").append(event.getString("price")).append("&euro;").append("</td>"
                                    + "<td>").append("<form class=\"join-button\" action=\"/joinevent\" method=\"GET\">"
                                    + "<input type=\"hidden\" name=\"eventName\" value=\"").append(event.getString("event"))
                            .append("\"><button class=\"join\">Ver classificações</button></form>").append("</td>"
                                    + "</tr>");
                }
                builder.append("</div>");
            }
            model.addAttribute("events", builder.toString());

        } else {
            String username = request.getRemoteUser();
            String role = handler.getRole(username);
            model.addAttribute("options", username + ", <a href=\"/logout\">Logout</a>");

            if (role.equals("STAFF")) {
                model.addAttribute("operations", "<a href=\"/newevent\">Register an event</a> <br>" +
                        "<a href=\"/registertime\">Register a time for participant</a> <br>");
            } else {
                model.addAttribute("operations", "<a href=\"/newinscricao\">Join an event</a> <br>"
                        + "<a href=\"/inscricoes\">Joined events</a> <br>");
            }
        }
        return "index";
    }

    @GetMapping("/registertime")
    public String registerTime(Model model,HttpServletRequest request) throws Exception {
        String username = request.getRemoteUser();
        if(username!=null){
            model.addAttribute("options", username + ", <a href=\"/logout\">Logout</a>");
        }else {
            model.addAttribute("options", "<a href=\"/login\">Sign in</a> | <a href=\"/newuser\">Register</a>");
        }

        JSONArray events=handler.getEvents("all",null,null);

        StringBuilder builder = new StringBuilder();

        if (events.isEmpty()) {
            builder.append("<p>Não há eventos disponiveis</p>");
        } else {
            builder.append("<div class=\"events_list\">");
            builder.append("<table>"
                    + "<tr>"
                    + "<th>Nome do evento</th>"
                    + "<th>Data</th>"
                    + "<th></th>"
                    + "</tr>");

            for (int i = 0; i < events.length(); i++) {
                JSONObject event = events.getJSONObject(i);

                String dateWithoutHour = event.getString("date").substring(0, event.getString("date").indexOf(" "));

                builder.append("<tr>"
                                + "<td>").append(event.getString("event")).append("</td>"
                                + "<td>").append(dateWithoutHour).append("</td>"
                                + "<td>").append("<form class=\"join-button\" action=\"/newtime\" method=\"GET\">"
                                + "<input type=\"hidden\" name=\"eventName\" value=\"").append(event.getString("event"))
                        .append("\"><button class=\"join\">Register Time</button></form>").append("</td>"
                                + "</tr>");
            }
            builder.append("</div>");
        }


        model.addAttribute("events", builder.toString());
        return "registertime";
    }

    @GetMapping("/newtime")
    public String newTime(@RequestParam String eventName, Model model,HttpServletRequest request) {
        String username = request.getRemoteUser();
        if(username!=null){
            model.addAttribute("options", username + ", <a href=\"/logout\">Logout</a>");
        }else {
            model.addAttribute("options", "<a href=\"/login\">Sign in</a> | <a href=\"/newuser\">Register</a>");
        }

        model.addAttribute("event", eventName);
        StringBuilder builder = new StringBuilder();
        builder.append("<form class=\"form\" id=\"form1\" method=\"GET\" action=\"/submittime\">"
                        + "<p class=\"input-label\">Name</p>"
                        + "<input type=\"text\" name=\"name\"><br>"
                        + "<p class=\"input-label\">Nºdo participante</p>"
                        + "<input type=\"text\" name=\"number\"><br>"
                        + "<p class=\"input-label\">Ponto da prova</p>"
                        + "<select name=\"checkpoint\">"
                        + "<option value=\"start\">Start</option>"
                        + "<option value=\"p1\">P1</option>"
                        + "<option value=\"p2\">P2</option>"
                        + "<option value=\"p3\">P3</option>"
                        + "<option value=\"finish\">Finish</option>"
                        + "</select><br>"
                        + "<p class=\"input-label\">Timestamp</p>"
                        + "<p class=\"input-label\">Data e Hora do Checkpoint</p>"
                        +"<input type=\"datetime-local\" name=\"checkpointDateTime\"><br>"
                        + "<input type=\"hidden\" name=\"eventName\" value=\"").append(eventName)
                        .append("\"><button type=\"submit\">Register Time</button>")
                        .append("</form>");
        model.addAttribute("form", builder.toString());

        return "newtime";
    }

    @GetMapping("/submittime")
    public String submitTime(@RequestParam String eventName,
                             @RequestParam String name,
                             @RequestParam String number,
                             @RequestParam String checkpoint,
                             @RequestParam String  checkpointDateTime, Model model) throws Exception {

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");
        Date parsedDate = dateFormat.parse(checkpointDateTime);

        // Agora, converta a data analisada para um objeto Timestamp
        Timestamp time = new Timestamp(parsedDate.getTime());

        int res = handler.saveTime(eventName, name, number, checkpoint, time);
        if(res==1){
            model.addAttribute("op","Sucesso no Registo de Tempo");
        }
        if(res==2){
            model.addAttribute("op","Update do checkpoint e de timestamp com sucesso.");
        }
        else if(res==-1){
            model.addAttribute("op","Erro no registo de tempo");
            model.addAttribute("reason","O nome do participante não existe nas inscrições do evento");
        }
        else if(res==-3){
            model.addAttribute("op","Erro no registo ou no update de tempo");
            model.addAttribute("reason","O nº de participante inserido não condiz com o nome do participante");
        }
        else if(res==-2){
            model.addAttribute("op","Erro no registo de tempo");
            model.addAttribute("reason","O timestamp inserido é menor que a data e a hora de inicio do evento.");
        }

        return "confirmations";
    }



    @GetMapping("/newinscricao")
    public String newInscricao(Model model,HttpServletRequest request) throws Exception {
        String username = request.getRemoteUser();
        if(username!=null){
            model.addAttribute("options", username + ", <a href=\"/logout\">Logout</a>");
        }else {
            model.addAttribute("options", "<a href=\"/login\">Sign in</a> | <a href=\"/newuser\">Register</a>");
        }

        JSONArray events = handler.getEvents("tojoin",null,null);
        StringBuilder builder = new StringBuilder();

        if (events.isEmpty()) {
            builder.append("<p>Não eventos disponiveis</p>");
        } else {
            builder.append("<div class=\"events_list\">");
            builder.append("<table>"
                    + "<tr>"
                    + "<th>Nome do evento</th>"
                    + "<th>Descrição</th>"
                    + "<th>Data</th>"
                    + "<th>Preço</th>"
                    + "<th></th>"
                    + "</tr>");

            for (int i = 0; i < events.length(); i++) {
                JSONObject event = events.getJSONObject(i);

                String dateWithoutHour = event.getString("date").substring(0, event.getString("date").indexOf(" "));

                builder.append("<tr>"
                                + "<td>").append(event.getString("event")).append("</td>"
                                + "<td>").append(event.getString("description")).append("</td>"
                                + "<td>").append(dateWithoutHour).append("</td>"
                                + "<td>").append(event.getString("price")).append("&euro;").append("</td>"
                                + "<td>").append("<form class=\"join-button\" action=\"/joinevent\" method=\"GET\">"
                                + "<input type=\"hidden\" name=\"eventName\" value=\"").append(event.getString("event"))
                        .append("\"><button class=\"join\">Join</button></form>").append("</td>"
                                + "</tr>");
            }
            builder.append("</div>");
        }
        model.addAttribute("events", builder.toString());
        return "newinscricao";
    }


    @GetMapping("/inscricoes")
    public String getInscricoes(Model model,HttpServletRequest request) throws Exception {
        String username = request.getRemoteUser();
        if(username!=null){
            model.addAttribute("options", username + ", <a href=\"/logout\">Logout</a>");
        }else {
            model.addAttribute("options", "<a href=\"/login\">Sign in</a> | <a href=\"/newuser\">Register</a>");
        }

        JSONArray events = handler.getInscricoes(username);
        StringBuilder builder = new StringBuilder();

        if (events.isEmpty()) {
            builder.append("<p>Não há inscrições em eventos</p>");
        } else {
            builder.append("<div class=\"events_list\">");
        builder.append("<table>"
                + "<tr>"
                + "<th>Nome do atleta     </th>"
                + "<th>Nome do evento     </th>"
                + "<th>Data do evento     </th>"
                + "<th>Estado do pagamento</th>"
                + "<th></th>"  // Adicionando uma coluna extra para o botão "Pay"
                + "</tr>");

        for (int i = 0; i < events.length(); i++) {
            JSONObject event = events.getJSONObject(i);

            String dateWithoutHour = event.getString("date").substring(0, event.getString("date").indexOf(" "));

            builder.append("<tr>"
                    + "<td>").append(event.getString("participant_name")).append("    </td>"
                    + "<td>").append(event.getString("event_name")).append("    </td>"
                    + "<td>").append(dateWithoutHour).append("    </td>"
                    + "<td>").append(event.getString("status")).append("    </td>"
                    + "<td>").append("<form class=\"pay-button\" action=\"/paymentevent\" method=\"GET\">"
                    + "<input type=\"hidden\" name=\"eventName\" value=\"").append(event.getString("event_name")).append("\">"
                    + "<input type=\"hidden\" name=\"participant_name\" value=\"").append(event.getString("participant_name")).append("\">"
                    + "<button type=\"submit\" class=\"join\">Pagar</button></form>").append("</td>");
            System.out.println(event.getString("participant_name"));
            }
            builder.append("</div>");
        }
        model.addAttribute("events", builder.toString());
        return "inscricoes";
    }

    @GetMapping("/paymentevent")
    public String paymentEvent(@RequestParam String eventName,
                               @RequestParam String participant_name,
                               Model model,HttpServletRequest request) throws Exception {
        String username = request.getRemoteUser();
        if(username!=null){
            model.addAttribute("options", username + ", <a href=\"/logout\">Logout</a>");
        }else {
            model.addAttribute("options", "<a href=\"/login\">Sign in</a> | <a href=\"/newuser\">Register</a>");
        }

        model.addAttribute("event",eventName);
        JSONObject res=handler.getPaymentInfo(eventName,participant_name);
        model.addAttribute("payment", "<p class=\"payment\">" + "Referência Multibanco: " + res.getString("mb_reference") + " Entidade: "+res.getString("mb_entity")+ " Valor: " + res.getString("value").toString()+"&euro;</p>");
        model.addAttribute("button","<form class=\"pay-button\" action=\"/confirmpayment\" method=\"GET\">"
                + "<input type=\"hidden\" name=\"eventName\" value=\""+eventName+"\">"
                + "<input type=\"hidden\" name=\"participant_name\" value=\""+participant_name+"\">"
                + "<button type=\"submit\" class=\"join\">Pagar</button></form>");
        return "paymentevent";
    }

    @GetMapping("/confirmpayment")
    public String confirmPayment(@RequestParam String eventName,
                                 @RequestParam String participant_name,
                                 Model model) throws Exception {
        model.addAttribute("op","Pagamento Confirmado");
        handler.confirmPay(eventName,participant_name);
        return "/inscricoes";
    }

    @GetMapping("/joinevent")
    public String joinEvent(@RequestParam String eventName, Model model,HttpServletRequest request) {
        String username = request.getRemoteUser();
        if(username!=null){
            model.addAttribute("options", username + ", <a href=\"/logout\">Logout</a>");
        }else {
            model.addAttribute("options", "<a href=\"/login\">Sign in</a> | <a href=\"/newuser\">Register</a>");
        }

        model.addAttribute("event", eventName);
        StringBuilder builder = new StringBuilder();
        builder.append("<form class=\"form\" id=\"form1\" method=\"GET\" action=\"/submitinscricao\">"
                        + "<p class=\"input-label\">Name</p>"
                        + "<input type=\"text\" name=\"name\"><br>"
                        + "<p class=\"input-label\">Gender</p>"
                        + "<select name=\"gender\">"
                        + "<option value=\"M\">M</option>"
                        + "<option value=\"F\">F</option>"
                        + "</select><br>"
                        + "<p class=\"input-label\">Tier</p>"
                        + "<select name=\"tier\">"
                        + "<option value=\"júnior\">Júnior</option>"
                        + "<option value=\"vet35\">vet35</option>"
                        + "<option value=\"vet50\">vet50</option>"
                        + "<option value=\"vet35\">vet65</option>"
                        + "</select><br>"
                        + "<input type=\"hidden\" name=\"eventName\" value=\"").append(eventName)
                .append("\"><button type=\"submit\">Join</button>")
                .append("</form>");
        model.addAttribute("form", builder.toString());

        return "joinevent";
    }

    @GetMapping("/submitinscricao")
    public String submitInscricao(@RequestParam String eventName,
                                  @RequestParam String name,
                                  @RequestParam String gender,
                                  @RequestParam String tier,
                                  Model model,HttpServletRequest request) throws Exception {
        String username = request.getRemoteUser();
        if(username!=null){
            model.addAttribute("options", username + ", <a href=\"/logout\">Logout</a>");
        }else {
            model.addAttribute("options", "<a href=\"/login\">Sign in</a> | <a href=\"/newuser\">Register</a>");
        }
        JSONObject res = handler.saveInscricao(eventName, username,name, gender, tier);

        if (res != null) {
            model.addAttribute("success", "<p class=\"success\">Sucesso</p>");
            model.addAttribute("payment", "<p class=\"payment\">" + "Referência Multibanco: " + res.getString("reference") + " Entidade: "+res.getString("entity")+ " Valor: " + res.getString("value").toString()+"&euro;"+"</p>");
        } else {
            model.addAttribute("success", "<p class=\"error\">failed</p>");
            model.addAttribute("reason", "<p>Erro na inscrição, verifique se o atleta não está já inscrito neste evento</p>");
        }

        return "submitinscricao";
    }


    @GetMapping("/newevent")
    public String newEvent(Model model,HttpServletRequest request) {
        String username = request.getRemoteUser();
        model.addAttribute("options", username + ", <a href=\"/logout\">Logout</a>");
        return "newevent";
    }


    @GetMapping("/registerevent")
    public String registerEvent(@RequestParam String name, @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd") Date date,
                                @RequestParam String description,
                                @RequestParam String value,
                                Model model) throws Exception {
        Event e = new Event(name, description, date, Double.parseDouble(value));
        int res = handler.saveEvent(e);

        if (res == 1) {
            model.addAttribute("op", "Event Registration");
            model.addAttribute("success", "<p class=\"success\">success</p>");
        } else {
            model.addAttribute("op", "Event Registration");
            model.addAttribute("success", "<p class=\"error\">failed</p>");
            model.addAttribute("reason", "<p>There is already an event with the same name</p>");
        }

        return "confirmations";
    }

    @GetMapping("/login")
    public String loginPage(Model model, @RequestParam(value = "error", required = false) String error,
                            @RequestParam(value = "logout", required = false) String logout) {
        if (error != null) {
            model.addAttribute("error", "Invalid Credentials");
        }
        if (logout != null) {
            model.addAttribute("msg", "You have been successfully logged out");
        }
        return "login";
    }

    @GetMapping("/logout")
    public String logoutPage(Model model, HttpServletRequest request) {
        request.getSession().invalidate();
        return "redirect:/";
    }


    @GetMapping("/newuser")
    public String newuser(Model model) {
        return "newuser";
    }

    @GetMapping("/register")
    public String register(@RequestParam String username,
                           @RequestParam String password,
                           @RequestParam String role,
                           Model model) throws Exception {


        User u = new User(username, password, role);
        int res = handler.saveUser(u);
        if (res == 1) {
            model.addAttribute("op", "User Registration");
            model.addAttribute("success", "<p class=\"success\">success</p>");
        } else {
            model.addAttribute("op", "User Registration");
            model.addAttribute("success", "<p class=\"error\">failed</p>");
            model.addAttribute("reason", "<p>Username is taken</p>");
        }

        return "confirmations";
    }
}
